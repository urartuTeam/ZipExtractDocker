insert into public.projects (project_id, name, department_id)
values  (6, 'ИАС УГД', 13),
        (7, 'СУИД', 7),
        (8, 'KPI', 11),
        (9, 'ОИВ', 11),
        (10, 'Герц', 11);