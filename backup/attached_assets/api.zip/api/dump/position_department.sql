insert into public.position_department (position_link_id, position_id, department_id, sort)
values  (3, 61, 1, 2),
        (2, 60, 1, 1),
        (6, 20, 1, 3),
        (7, 62, 1, 3),
        (9, 22, 1, 3),
        (4, 1, 1, 2),
        (5, 19, 1, 3),
        (15, 63, 1, 4),
        (8, 63, 1, 4);