insert into public.leaves (leave_id, employee_id, start_date, end_date, type)
values  (1, 26, '2023-01-01', null, 'По уходу за ребенком');