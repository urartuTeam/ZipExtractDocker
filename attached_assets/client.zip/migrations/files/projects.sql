INSERT INTO public.projects (project_id, name, department_id) VALUES (1, 'Городской портал цифровизации', 2);
INSERT INTO public.projects (project_id, name, department_id) VALUES (2, 'Система аналитики градостроительных данных', 2);
INSERT INTO public.projects (project_id, name, department_id) VALUES (3, 'Разработка API градостроительных данных', 3);
