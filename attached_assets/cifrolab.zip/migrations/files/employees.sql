INSERT INTO public.employees (employee_id, full_name, position_id, phone, email, manager_id, department_id) VALUES (1, 'Степанова Дарья Владимировна', 1, '+7 (111) 111-11-11', 'mail@example.com', null, 1);
INSERT INTO public.employees (employee_id, full_name, position_id, phone, email, manager_id, department_id) VALUES (2, 'Герц Владимир Андреевич', 6, null, null, 1, 1);
INSERT INTO public.employees (employee_id, full_name, position_id, phone, email, manager_id, department_id) VALUES (3, 'Терновский Андрей Викторович', 9, null, null, null, 1);
INSERT INTO public.employees (employee_id, full_name, position_id, phone, email, manager_id, department_id) VALUES (4, 'Подгорный Александр Владимирович', 4, null, null, null, 1);
