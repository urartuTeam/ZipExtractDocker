INSERT INTO public.departments (department_id, name, parent_department_id, parent_position_id, deleted, deleted_at) VALUES (1, 'Администрация', null, null, false, null);
INSERT INTO public.departments (department_id, name, parent_department_id, parent_position_id, deleted, deleted_at) VALUES (2, 'Управление цифровизации и градостроительных данных', 1, 6, false, null);
INSERT INTO public.departments (department_id, name, parent_department_id, parent_position_id, deleted, deleted_at) VALUES (3, 'Управление цифрового развития', 1, 6, false, null);
