INSERT INTO public.employeeprojects (employee_id, project_id, role) VALUES (1, 1, 'Руководитель проекта');
INSERT INTO public.employeeprojects (employee_id, project_id, role) VALUES (2, 1, 'Архитектор системы');
INSERT INTO public.employeeprojects (employee_id, project_id, role) VALUES (3, 1, 'Технический директор');
INSERT INTO public.employeeprojects (employee_id, project_id, role) VALUES (4, 2, 'Руководитель проекта');
INSERT INTO public.employeeprojects (employee_id, project_id, role) VALUES (3, 3, 'Руководитель проекта');
